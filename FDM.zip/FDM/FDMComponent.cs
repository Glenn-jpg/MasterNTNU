﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;
using FDM.Classes;
using la = MathNet.Numerics.LinearAlgebra;

// In order to load the result of this wizard, you will also need to
// add the output bin/ folder of this project to the list of loaded
// folder in Grasshopper.
// You can use the _GrasshopperDeveloperSettings Rhino command for that.

namespace FDM
{
    public class FDMComponent : GH_Component
    {
        /// <summary>
        /// Each implementation of GH_Component must provide a public 
        /// constructor without any arguments.
        /// Category represents the Tab in which the component will appear, 
        /// Subcategory the panel. If you use non-existing tab or panel names, 
        /// new tabs/panels will automatically be created.
        /// </summary>
        public FDMComponent()
          : base("Force Density Method", "FDM",
              "Description",
              "M_testing", "Form Finding")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddLineParameter("Lines", "l", "Lines representing individual bars in grid", GH_ParamAccess.list);
            pManager.AddNumberParameter("Force densities", "q", "The force densities of the bars", GH_ParamAccess.list);
            pManager.AddPointParameter("Support points", "sp", "The strucutres suport points", GH_ParamAccess.list);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("p", "", "", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {

            #region Assesing input data
            List<Line> lines = new List<Line>();
            List<double> qs = new List<double>();
            List<Point3d> sPts = new List<Point3d>();

            if (!DA.GetDataList(0, lines)) return;
            if (!DA.GetDataList(1, qs)) return;
            if (!DA.GetDataList(2, sPts)) return;
            #endregion

            // Pairing lines and densities
            List<LQPair> l_q_pairs = new List<LQPair>();
            for (int i = 0; i < lines.Count; i++)
            {
                l_q_pairs.Add(new LQPair(lines[i], qs[i]));
            }

            // 

            List<Point3d> sortList = SortPoints(l_q_pairs, sPts);
            la.Matrix<double> BNMatrix = BuildBranchNodeMatrix(l_q_pairs, sortList);


            // Set data
            // DA.SetDataList(0, sortList);
            DA.SetData(0, BNMatrix);
        }

        // Fuctions
        private List<Point3d> SortPoints(List<LQPair> Branches, List<Point3d> supPoints)
        {
            List<Point3d> sortedPts = new List<Point3d>();
            foreach(Point3d p in supPoints) { sortedPts.Add(p); }

            foreach(LQPair b in Branches)
            {
                Point3d spt = b.line.PointAt(0);
                Point3d ept = b.line.PointAt(1);
                bool addit1 = true;
                bool addit2 = true;
                foreach(Point3d p in sortedPts)
                {
                    if (p.DistanceTo(spt) < 0.001) addit1 = false;
                    if (p.DistanceTo(ept) < 0.001) addit2 = false;
                }
                if (addit1) sortedPts.Add(spt);
                if (addit2) sortedPts.Add(ept);
            }
            sortedPts.RemoveRange(0, supPoints.Count);
            sortedPts.AddRange(supPoints);
            return sortedPts;
        }

        private la.Matrix<double> BuildBranchNodeMatrix(List<LQPair> branches, List<Point3d> _sortedPoints)
        {
            la.Matrix<double> c = la.Double.Matrix.Build.Dense(branches.Count, _sortedPoints.Count, 0);
            foreach(LQPair b in branches) 
            {
                int row = b.id;
                Point3d sPt = b.line.PointAt(0);
                Point3d ePt = b.line.PointAt(1);
                int col1 = 0;
                int col2 = 0;
                int i = 0;
                foreach(Point3d p in _sortedPoints)
                {
                    if (sPt.DistanceTo(p) < 0.001) col1 = i;
                    if (ePt.DistanceTo(p) < 0.001) col2 = i;
                    i += 1;
                }
                c[row, col1] = 1;
                c[row, col2] = -1;           
            }
            return c;
        }

        private la.Vector<double> ForceDensityVector(List<LQPair> branches)
        {
            la.Vector<double> q = la.Double.Vector.Build.Dense(branches.Count);
            for (int i = 0; i < branches.Count; i++)
            {
                q[i] = branches[i].ratio;
            }

            return q;
        }

        private List<la.Vector<double>> CoordinateVectors(List<Point3d> sortedPts)
        {
            la.VectorBuilder<double> v = la.Double.Vector.Build;
            la.Vector<double> x = v.Dense(sortedPts.Count);
            la.Vector<double> y = v.Dense(sortedPts.Count);
            la.Vector<double> z = v.Dense(sortedPts.Count);
            for (int i = 0; i < sortedPts.Count; i++)
            {
                x[i] = sortedPts[i].X;
                y[i] = sortedPts[i].Y;
                z[i] = sortedPts[i].Z;
            }
            List<la.Vector<double>> cordVecs = new List<la.Vector<double>>();
            cordVecs.Add(x);
            cordVecs.Add(y);
            cordVecs.Add(z);
            return cordVecs;
        }



        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                // You can add image files to your project resources and access them like this:
                //return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Each component must have a unique Guid to identify it. 
        /// It is vital this Guid doesn't change otherwise old ghx files 
        /// that use the old ID will partially fail during loading.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("ae22d833-c642-4c28-a7b9-85ae163f7b4f"); }
        }
    }
}
